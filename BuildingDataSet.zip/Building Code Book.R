Real Estate Across the United States (REXUS) is the primary tool used by PBS to 
track and manage the government's real property assets and to store inventory 
data, building data, customer data, and lease information. STAR manages aspects 
of real property space management, including identification of all building 
space and daily management of 22,000 assignments for all property to its client 
Federal agencies. This data set contains PBS building inventory that consists of
both owned and leased buildings with active and excess status.
Real Estate Across the United States (REXUS) is the main tool used by the PBS to
track and manage the government's real 
write in own words.

https://catalog.data.gov/dataset/real-estate-across-the-united-states-rexus-inventory-building

Author 	General Services Administration
Maintainer	Tom Uba


Location code: Location code
Region code: Type of reigion
BLDG Address: Address of building
BLDG Address 2: 2nd address for bigger buildings 
BLDG city: city where building is at
BLDG County : county location 
BLDG State: State where building is at
BLDG Zip : Zip code
BLDG Status: Active or not active
Building type: Structure or building? building type
Total parking spaces: total parking spaces